    <?php
        $dbServername="localhost:3307";
        $dbUsername="root";
        $dbPassword="";
        $dbName="flora_database";
        $conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
    ?>
